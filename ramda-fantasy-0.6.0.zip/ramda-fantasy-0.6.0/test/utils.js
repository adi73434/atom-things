var R = require('ramda');

module.exports = {
  equalsInvoker: R.invoker(1, 'equals')
};
